const userRoutes = require("./userRoutes");
const productRoutes = require("./productRoutes");
const cartRoutes = require("./cartRoutes");
module.exports = {
  userRoutes,
  productRoutes,
  cartRoutes,
};
